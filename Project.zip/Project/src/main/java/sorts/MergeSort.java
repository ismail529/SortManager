package sorts;

public class MergeSort {
    public static void mergeSort(int[] mergeArray, int lowerEnd, int upperEnd) {
        if (lowerEnd >= upperEnd ) return;
        int middle = (lowerEnd + upperEnd) / 2;
        mergeSort(mergeArray, lowerEnd, middle);
        mergeSort(mergeArray, middle + 1, upperEnd);
        merge(mergeArray, lowerEnd, middle, upperEnd);
    }

    public static void merge(int[] mergeArray, int low, int mid, int high) {
        int temp1 = 0;
        int temp2 = 0;
        int tempArray[] = new int[mid - low + 1];
        int tempArray2[] = new int[high - mid];

        for (int i = 0; i < tempArray.length; i++)
            tempArray[i] = mergeArray[low + i];
        for (int j = 0; j < tempArray2.length; j++)
            tempArray2[j] = mergeArray[mid + j + 1];

        for (int k = low; k < high + 1; k++) {
            if (temp1 < tempArray.length && temp2 < tempArray2.length) {
                if (tempArray[temp1] < tempArray2[temp2]) {
                    mergeArray[k] = tempArray[temp1];
                    temp1++;
                } else {
                    mergeArray[k] = tempArray2[temp2];
                    temp2++;
                }
            } else if (temp1 < tempArray.length) {
                mergeArray[k] = tempArray[temp1];
                temp1++;
            } else if (temp2 < tempArray2.length) {
                mergeArray[k] = tempArray2[temp2];
                temp2++;
            }
        }
    }
}