package sorts;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Starter {
    public static void starter() throws ChildNotFoundException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("please choose one of the following examples of numbers for sorters: 1)bubble or 2) insertion 3)merge 4)quick 5)selection 6)binary tree");
        int number = scanner.nextInt();
        System.out.println("the number you entered is " + number);

        System.out.println("please choose the length of array" );
        int temp = scanner.nextInt();
        Random random = new Random();

        int[] arrayExample = new int[temp];
        long start = System.nanoTime();

        for (int i =0;i<arrayExample.length;i++) {
            arrayExample[i]=Math.abs(random.nextInt());
        }

        if (number == 1) {
            System.out.println("unsorted array:");
            System.out.println(Arrays.toString(arrayExample));
            InsertionSort.insertionSort(arrayExample);
            System.out.println("sorted array:");
            System.out.println(Arrays.toString(arrayExample));
        } else if (number == 2) {
            System.out.println("unsorted array");
            System.out.println(Arrays.toString(arrayExample));
            BubbleSort.bubbleSort((arrayExample));
            System.out.println("sorted array");
            System.out.println(Arrays.toString(arrayExample));
        } else if (number == 3) {
            System.out.println("unsorted array");
            System.out.println(Arrays.toString(arrayExample));
            MergeSort.mergeSort(arrayExample,0,2);
            System.out.println("sorted array");
            System.out.println(Arrays.toString(arrayExample));
        }  else if (number == 4) {
            System.out.println("unsorted array");
            System.out.println(Arrays.toString(arrayExample));
           SelectionSort.selectionSort((arrayExample));
            System.out.println("sorted array");
            System.out.println(Arrays.toString(arrayExample));
        }  else if (number == 5) {
            System.out.println("unsorted array");
            System.out.println(Arrays.toString(arrayExample));
            QuickSort.quickSort(arrayExample,0,2);
            System.out.println("sorted array");
            System.out.println(Arrays.toString(arrayExample));
        } else if (number == 6) {
            System.out.println("unsorted array");
            System.out.println(Arrays.toString(arrayExample));
            BinaryTreeSort.SortBinaryTree(arrayExample);
            System.out.println("sorted array");
            System.out.println(Arrays.toString(arrayExample));
        }

        long finish = System.nanoTime();
        System.out.println((finish-start)/1_000_000 + " time taken");

    }
}



