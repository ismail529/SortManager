package sorts;

public class ChildNotFoundException extends Exception{
    public String getMessage ( ){
        return "Cannot be found in binary tree";
    }
}
