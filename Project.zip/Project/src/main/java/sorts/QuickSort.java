package sorts;

public class QuickSort {
    public static int split(int[] quickSortArray, int lowerEnd, int higherEnd) {
        int tempPivot = quickSortArray[higherEnd];
        int i = (lowerEnd-1);
        for (int j=lowerEnd; j<higherEnd; j++) {
            if (quickSortArray[j] <= tempPivot) {
                i++;
                int temp = quickSortArray[i];
                quickSortArray[i] = quickSortArray[j];
                quickSortArray[j] = temp;
            }
        }
        int temp = quickSortArray[i+1];
        quickSortArray[i+1] = quickSortArray[higherEnd];
        quickSortArray[higherEnd] = temp;
        return i+1;
    }

   public static void quickSort(int[] intArray, int lowerEnd, int higherEnd) {
        if (lowerEnd < higherEnd) {
            int pivot = split(intArray, lowerEnd, higherEnd);
            quickSort(intArray, lowerEnd, pivot-1);
            quickSort(intArray, pivot+1, higherEnd);
        }
    }
}

