package sorts;

public class BubbleSort {
    public static void bubbleSort(int[] bubbleArray)
    {
        int temp = 0;
        for (int i = 0; i < bubbleArray.length-1; i++)
            for (int j = 0; j < bubbleArray.length-i-1; j++)
                if (bubbleArray[j] > bubbleArray[j+1])
                {
                    temp = bubbleArray[j];
                    bubbleArray[j] = bubbleArray[j+1];
                    bubbleArray[j+1] = temp;
                }
    }
}
