package sorts;

public interface BinaryTreeInterface {
    int getRootElement();
    int getNumberOfElements();
    void addElement(final int element);
    void addElements(final int[] elements);
    boolean findElement(final int value);
    int getLeftChild(int element) throws ChildNotFoundException;
    int getRightChild(int element) throws ChildNotFoundException;
    int[] getSortedTreeAsc();
    int[] getSortedTreeDesc();
}
