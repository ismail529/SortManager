package sorts;

public class SelectionSort {
    public static void selectionSort(int[] selectionSortArray) {
        int temp = selectionSortArray.length;
        for (int i = 0; i < temp - 1; i++) {
            int lowerEnd = i;
            for (int j = i + 1; j < temp; j++) {
                if (selectionSortArray[j] > selectionSortArray[lowerEnd]) {
                    lowerEnd = j;
                }
            }
            int temp2 = selectionSortArray[i];
            selectionSortArray[i] = selectionSortArray[lowerEnd];
            selectionSortArray[lowerEnd] = temp2;
        }
    }
}
