package sorts;

public class BinaryTreeSort {
    public static int[] SortBinaryTree(int[] inArray) {
        BinaryTree binaryTree = new BinaryTree(inArray[0]);
        for (int i = 1; i < inArray.length; i++) {
            binaryTree.addElement(inArray[i]);
        }
        return binaryTree.getSortedTreeAsc();
    }
}


