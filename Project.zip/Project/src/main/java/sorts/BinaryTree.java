package sorts;
import java.util.ArrayList;

public class BinaryTree implements BinaryTreeInterface {
    private final Node rootNode;
    int elementsCount;

    public BinaryTree(final int element) {
        rootNode = new Node(element);
        elementsCount++;
    }
    public void addElement(final int element) {
        addNodeToTree(rootNode, element);
    }

    @Override
    public int getRootElement() {
        return rootNode.getValue();
    }

    @Override
    public int getNumberOfElements() {
        return elementsCount;
    }

    @Override
    public void addElements(int[] elements) {
        for (int i = 0; i < elements.length; i++) {
            addElement(elements[i]);
        }
    }

    @Override
    public boolean findElement(int value) {
        if (findNode(value) != null) {
            return true;
        }
        return false;
    }

    @Override
    public int getLeftChild(int element) throws ChildNotFoundException {
        Node node = findNode(element);
        Node leftChild = null;
        if (node != null) {
            leftChild = node.getLeftChild();
        } else {
            throw new ChildNotFoundException();
        }
        return leftChild.getValue();
    }

    @Override
    public int getRightChild(int element) throws ChildNotFoundException {
        Node node = findNode(element);
        Node rightChild = null;
        if (node != null) {
            rightChild = node.getRightChild();
        } else {
            throw new ChildNotFoundException();
        }
        return rightChild.getValue();
    }

    private ArrayList<Integer> descOrder(Node node, ArrayList<Integer> arrayList) {
        if (node == null)
            return arrayList;
        descOrder(node.getRightChild(), arrayList);
        arrayList.add(node.getValue());
        descOrder(node.getLeftChild(), arrayList);
        return arrayList;
    }

    private ArrayList<Integer> ascOrder(Node node, ArrayList<Integer> arrayList) {
        if (node == null)
            return arrayList;
        ascOrder(node.getLeftChild(), arrayList);
        arrayList.add(node.getValue());
        ascOrder(node.getRightChild(), arrayList);
        return arrayList;
    }

    @Override
    public int[] getSortedTreeAsc() {
        ArrayList<Integer> result = this.ascOrder(this.rootNode, new ArrayList<Integer>());
        int[] resultArray = new int[result.size()];
        for (int i = 0; i < resultArray.length; i++) {
            resultArray[i] = result.get(i).intValue();
        }
        return resultArray;
    }

    @Override
    public int[] getSortedTreeDesc() {
        ArrayList<Integer> result = this.descOrder(this.rootNode, new ArrayList<Integer>());
        int[] resultArray = new int[result.size()];
        for (int i = 0; i < resultArray.length; i++) {
            resultArray[i] = result.get(i).intValue();
        }
        return resultArray;
    }

    private void addNodeToTree(Node node, int element) {
        if (element == node.getValue()) return;

        if (element < node.getValue()) {
            if (node.isLeftChildEmpty()) {
                node.setLeftChild(new Node(element));
                elementsCount++;
            } else {
                addNodeToTree(node.getLeftChild(), element);
            }
        } else if (element > node.getValue()) {
            if (node.isRightChildEmpty()) {
                node.setRightChild(new Node(element));
                elementsCount++;
            } else {
                addNodeToTree(node.getRightChild(), element);
            }
        }
    }

    public Node findNode(int element) {
        Node node = rootNode;
        while (node != null) {
            if (element == node.getValue()) {
                return node;
            }
            if (element < node.getValue()) {
                node = node.getLeftChild();
            } else {
                node = node.getRightChild();
            }
        }
        return null;
    }
}
