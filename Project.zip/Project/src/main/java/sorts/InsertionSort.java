package sorts;

public class InsertionSort {
    public static void insertionSort(int[] insertArray) {
        int temp;
        for (int i = 1; i < insertArray.length; ++i) {
            temp = insertArray[i];
            int j = i - 1;
            while ((j >= 0) && (insertArray[j] > temp)) {
                insertArray[j + 1] = insertArray[j];
                j = j - 1;
            }
            insertArray[j + 1] = temp;
        }
    }
}
